All options in these folders that changed color settings have had those options removed from here
and placed in clientscheme_colors.res in the resource/scheme folder. For instructions on how to do 
this and important details, read the main readme in the download folder, or consult the tutorial 
video I will have linked in the main description of the HUD.